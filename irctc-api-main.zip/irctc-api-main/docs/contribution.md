---
layout: page
title: "Contribution"
permalink: /contribution
---

You need to fork the repository and then rasie a pull request and when the pull request is approved your changes will be applied to next scheduled release

## Useful Links

<a href="https://github.com/LIKHITHANARRA/irctc-api"><img src="https://github.githubassets.com/assets/GitHub-Mark-ea2971cee799.png" alt="GitHub Logo" width="50" height="50"/></a> <a href="https://www.npmjs.com/package/irctc-api"><img src="https://upload.wikimedia.org/wikipedia/commons/d/db/Npm-logo.svg" alt="npm Logo" width="50" height="50"/></a> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Read-the-docs.png/330px-Read-the-docs.png" alt="Documentation Logo" width="50" height="50"/></a>

## Copyright

All Rights Reserved. &copy;LIKHITHA NARRA, 2024
